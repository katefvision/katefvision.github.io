#!/usr/bin/env python

from distutils.core import setup

setup(
    name='DeepRL Homework 2',
    version='1.0',
    description='Library for 10-703 Homework 2',
    packages=['deeprl_hw2'])
